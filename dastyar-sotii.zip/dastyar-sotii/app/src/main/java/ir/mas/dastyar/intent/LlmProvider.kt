package ir.mas.dastyar.intent

/**
 * لایه Abstraction اصلی روی «مغز» اپ.
 *
 * قرارداد امنیتی مهم: پیاده‌سازی‌های این اینترفیس هرگز نباید مستقیماً به APIهای
 * حساس اندروید (Contacts/Call/SMS) دسترسی داشته باشند. آنها فقط اجازه دارند
 * یکی از حالت‌های ParsedIntent را برگردانند؛ اجرای واقعی عملیات همیشه در
 * ConversationViewModel و پس از تأیید کاربر (برای CALL_CONTACT) انجام می‌شود.
 *
 * برای CALL_CONTACT فقط نام مخاطب (نه کل متن گفتار، نه دفترچه مخاطبین) باید
 * به این لایه داده شود. برای READ_SMS هیچ متن پیامکی هرگز نباید به این لایه
 * وارد شود.
 *
 * پیاده‌سازی پیش‌فرض MVP: [RuleBasedLlmProvider] (رایگان، آفلاین، بدون هیچ
 * وابستگی خارجی). در آینده می‌توان [OnDeviceLlmProvider] (مدل کوچک محلی مثل
 * Gemma/Qwen کوانتیزه) یا یک provider ابری اختیاری را جایگزین کرد، بدون
 * نیاز به تغییر بقیه اپ.
 */
interface LlmProvider {

    /**
     * متن گفتار کاربر (خروجی STT) را می‌گیرد و یکی از حالت‌های ParsedIntent
     * را برمی‌گرداند. اگر مدل/قوانین نتوانند با اطمینان تصمیم بگیرند، باید
     * ParsedIntent.Invalid یا ParsedIntent.Chat برگردانده شود — هرگز نباید
     * حدسی برای CALL_CONTACT یا READ_SMS بدون اطمینان کافی زده شود.
     */
    suspend fun classify(userUtterance: String): ParsedIntent

    /** نام قابل‌نمایش provider، برای لاگ/دیباگ. */
    val providerName: String
}
