package ir.mas.dastyar.intent

/**
 * خروجی معتبر و ساختاریافته‌ای که تنها این ماژول اجازه تولید آن را دارد.
 * هیچ بخش دیگری از اپ (از جمله LlmProvider) نباید مستقیماً عملیات حساس
 * (تماس / خواندن پیامک) را اجرا کند؛ همه چیز باید از این مدل عبور کند.
 */
sealed class ParsedIntent {

    /** گفتگوی عادی. اگر پاسخ از پیش تولید نشده باشد null است. */
    data class Chat(val reply: String? = null) : ParsedIntent()

    /** درخواست تماس با یک مخاطب؛ contactName خام از گفتار کاربر استخراج شده است. */
    data class CallContact(val contactName: String) : ParsedIntent()

    /** درخواست خواندن پیامک‌های دریافتی. */
    data object ReadSms : ParsedIntent()

    /** خروجی نامعتبر/مبهم از مدل. هیچ عملیات حساسی نباید بر اساس این اجرا شود. */
    data class Invalid(val reason: String) : ParsedIntent()
}

/** دستورات ناوبری هنگام خواندن پیامک؛ اینها هرگز به LLM نیازی ندارند و می‌توانند کاملاً Regex باشند. */
enum class SmsNavigationCommand {
    NEXT, PREVIOUS, REPEAT, STOP, UNKNOWN
}
