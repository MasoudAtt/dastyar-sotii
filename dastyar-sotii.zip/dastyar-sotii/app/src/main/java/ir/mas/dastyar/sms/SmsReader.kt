package ir.mas.dastyar.sms

import android.content.Context
import android.provider.Telephony

data class SmsMessage(
    val sender: String,
    val body: String,
    val timestampMillis: Long
)

/**
 * خواندن پیامک‌های صندوق ورودی از Telephony Provider، مرتب‌شده از جدید به قدیم.
 *
 * نکته حریم‌خصوصی مهم طبق طراحی امنیتی پروژه: متن پیامک‌ها هرگز از این کلاس
 * به بیرون از دستگاه (و مخصوصاً هرگز به LlmProvider) ارسال نمی‌شود؛ فقط
 * مستقیماً توسط TextToSpeechProvider خوانده می‌شود.
 */
class SmsReader(private val context: Context) {

    fun loadRecentMessages(limit: Int = 20): List<SmsMessage> {
        val results = mutableListOf<SmsMessage>()
        val resolver = context.contentResolver

        val projection = arrayOf(
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE
        )

        resolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            projection,
            null,
            null,
            "${Telephony.Sms.DATE} DESC LIMIT $limit"
        )?.use { cursor ->
            val addressIdx = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
            val bodyIdx = cursor.getColumnIndex(Telephony.Sms.BODY)
            val dateIdx = cursor.getColumnIndex(Telephony.Sms.DATE)

            while (cursor.moveToNext()) {
                val address = if (addressIdx >= 0) cursor.getString(addressIdx) else null
                val body = if (bodyIdx >= 0) cursor.getString(bodyIdx) else null
                val date = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L

                if (body.isNullOrBlank()) continue
                results += SmsMessage(
                    sender = address ?: "ناشناس",
                    body = body,
                    timestampMillis = date
                )
            }
        }

        return results
    }
}
