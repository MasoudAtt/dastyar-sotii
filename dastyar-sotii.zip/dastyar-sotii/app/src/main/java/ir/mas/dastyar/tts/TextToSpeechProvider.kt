package ir.mas.dastyar.tts

/**
 * لایه Abstraction روی موتور تبدیل متن به گفتار.
 *
 * پیاده‌سازی MVP فعلی ([AndroidSystemTtsProvider]) از موتور TTS سیستم اندروید
 * استفاده می‌کند. طبق سند امکان‌سنجی، پشتیبانی فارسی موتورهای TTS سیستمی
 * ناسازگار/ناکامل گزارش شده؛ قدم بعدی جایگزینی با یک موتور Piper آفلاین
 * (با صدای فارسی جامعه‌محور) به‌علاوه eSpeak-NG به‌عنوان fallback تضمینی است.
 */
interface TextToSpeechProvider {

    fun isAvailable(): Boolean

    fun speak(text: String, onDone: () -> Unit = {}, onError: (() -> Unit)? = null)

    fun stop()

    fun destroy()
}
