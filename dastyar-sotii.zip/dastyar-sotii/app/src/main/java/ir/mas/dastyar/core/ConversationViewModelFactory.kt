package ir.mas.dastyar.core

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import ir.mas.dastyar.DastyarApp

class ConversationViewModelFactory(private val app: DastyarApp) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ConversationViewModel(
            stt = app.sttProvider,
            tts = app.ttsProvider,
            llm = app.llmProvider,
            contactsResolver = app.contactsResolver,
            callManager = app.callManager,
            smsReader = app.smsReader
        ) as T
    }
}
