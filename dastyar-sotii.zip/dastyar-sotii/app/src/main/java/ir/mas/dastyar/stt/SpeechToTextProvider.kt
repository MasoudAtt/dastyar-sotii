package ir.mas.dastyar.stt

/**
 * لایه Abstraction روی موتور تبدیل گفتار به متن.
 *
 * پیاده‌سازی MVP فعلی ([AndroidSystemSttProvider]) از سرویس تشخیص گفتار
 * سیستم اندروید استفاده می‌کند تا مسیر کامل صدا→متن→Intent→عملیات هر چه
 * زودتر قابل تست روی گوشی واقعی باشد. طبق تحلیل امکان‌سنجی پروژه، این
 * پیاده‌سازی به Google Play Services وابسته است که در ایران همیشه قابل
 * اعتماد نیست؛ به همین دلیل قدم بعدی برنامه‌ریزی‌شده جایگزینی آن با
 * [VoskSttProvider] (کاملاً آفلاین، بدون وابستگی به گوگل) است — بدون نیاز
 * به تغییر در بقیه اپ، چون همه از همین اینترفیس استفاده می‌کنند.
 */
interface SpeechToTextProvider {

    /** آیا این پیاده‌سازی روی این گوشی/نسخه اندروید قابل استفاده است؟ */
    fun isAvailable(): Boolean

    /**
     * شروع شنیدن. فقط یکی از callbackها برای هر بار شنیدن صدا زده می‌شود.
     * @param onPartialResult در صورت پشتیبانی، متن جزئی حین صحبت‌کردن (اختیاری، ممکن است هرگز صدا زده نشود)
     */
    fun startListening(
        onResult: (String) -> Unit,
        onError: (SttError) -> Unit,
        onPartialResult: (String) -> Unit = {}
    )

    fun stopListening()

    fun destroy()
}

enum class SttError {
    NO_PERMISSION,
    NO_SPEECH_DETECTED,
    NETWORK_OR_SERVICE_UNAVAILABLE,
    UNKNOWN
}
